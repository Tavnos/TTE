Translate Transcript Eval v1

This tool is made for an ideal and fast bio-chem analysis,
of DNA, mRNA, Amino acids, peptides and Proteins.
There is thereby two ways of using this program repeatedly 

DNA/mRNA translation and evaluation with:
 - Total amount of peptides produced by translation
 - Distributed and total weight, and BLOSUM62 score
 - Additional statistics such as polarity and charge…
 
DNA configuration prediction of Peptide / Amino acid chains:
 - Linear arrengement from chronological iteration of configuration.
 - Supplementary configuration from random prediction.

More refinements will be coming soon such as: 
 - Protein folding estimation and statistics.
 - Executables for Windows and Linux
 - DNA GANs for intuitional optimisation.
 - Fancier GUI, French and Danish translation. 

Enjoy. 
Big credit to everyone that provided 
an amaizing ammount of knowledge from 
Wikipedia!
Made by Tavnos Terrence
Copyright [2018] [Alexandre Vieira]